1. 安装typora主程序
2. 确认你的电脑安装有nodejs，没有的话自己去下载安装
3. 打开终端，进入crack文件夹，运行以下命令自动安装依赖

```shell
npm install
```

4. 打开typora，点击【离线激活】这里会有一个【机器码】，复制下来，一会要用。软件不要退出
5. 打开crack.cjs，按照自己实际情况修改typora安装位置(第209行)

```typescript
const Typora_Installation_Path = "C:\\Program Files\\Typora";
```

4. 以管理员权限运行终端，终端中运行

```shell
node crack.cjs
```

6. 按照提示，将复制的【机器码】输入进去，然后输入【邮箱地址】，然后输入【y】,【n】,然后等着就完了。
7. 破解成功 enjoy